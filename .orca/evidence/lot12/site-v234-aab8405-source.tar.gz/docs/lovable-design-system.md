# Lovable design system visible contract

## Règle de vérité

Lovable est la spécification visuelle visible : il montre les surfaces, la hiérarchie,
les états, les proportions et les compositions à arbitrer. Storybook est l’exécution
vérifiable : il rend les composants de production avec des fixtures synthétiques. Le
code est l’implémentation : il porte l’API React, les tokens, le markup et
l’accessibilité.

En cas d’écart, on ouvre un diff visuel et on arbitre explicitement. On ne corrige pas
un écart en ajoutant un override local ou une seconde primitive.

## Contrat des tokens canoniques

Les tokens ci-dessous sont les seuls points de référence visuels pour les primitives,
les écrans de production et Storybook. Ils sont définis dans le bloc `:root` de
`app/globals.css`. Cette documentation référence les noms de tokens ; elle ne recopie
aucune valeur de couleur, de police ou d’effet afin d’éviter une seconde source de
vérité.

| Famille | Tokens gagnants | Règle d’usage |
|---|---|---|
| Police | `--font-family-sans`, `--font-geist-mono`, `--font-discovery-title` | Le texte UI utilise `--font-family-sans`; le titre Discovery utilise son rôle sémantique dédié et reste au-dessus des valeurs, métadonnées et labels internes ; le monospace est réservé aux données qui le nécessitent. |
| Couleurs sémantiques | `--color-bg`, `--color-bg-elevated`, `--color-surface`, `--color-surface-raised`, `--color-surface-active`, `--color-border`, `--color-border-strong`, `--color-text`, `--color-text-secondary`, `--color-text-muted`, `--color-accent`, `--color-accent-strong`, `--color-positive`, `--color-negative`, `--color-warning`, `--color-info`, `--color-violet`, `--color-content-copy` | Les composants consomment les rôles sémantiques ; aucune couleur littérale ne doit être ajoutée dans une primitive. |
| Surfaces | `--surface-canvas`, `--surface-primary`, `--surface-secondary`, `--surface-glass`, `--surface-glass-fallback`, `--surface-stroke`, `--surface-stroke-strong`, `--surface-highlight`, `--surface-blur` | `Surface` et ses wrappers déterminent la hiérarchie primaire, secondaire et glass. |

Le canvas et les surfaces de contenu sont blancs sur tous les écrans. Les éléments de structure ne reçoivent pas de surface. `primary` ou `secondary` porte uniquement une unité de contenu qui bénéficie d’une séparation visuelle; les disclosures, wrappers de page et groupes restent plats et transparents, plutôt que d’encadrer des cartes supplémentaires. Le chrome de navigation utilise `glass`. Les textes rédigés s’alignent à gauche et seules les valeurs KPI se centrent. Les groupes de trois scénarios et seuils sont à trois colonnes dès 761 px et en lignes pleine largeur sur mobile, sans disposition `2 + 1`.
| Rayons | `--radius-sm`, `--radius-md`, `--radius-lg`, `--radius-pill` | Les rayons sont choisis par rôle ; une nouvelle valeur locale doit être justifiée dans le contrat. |
| Ombres | `--surface-shadow`, `--surface-shadow-glass`, `--shadow-panel` | Une surface ne redéfinit pas son ombre localement pour corriger une divergence visuelle. |
| Contrôles | `--control-height`, `--ui-control-height`, `--ui-control-hit-height`, `--ui-control-contained-height`, `--ui-control-radius`, `--ui-progress-track`, `--ui-progress-accent`, `--ui-progress-positive`, `--ui-progress-warning`, `--ui-progress-height` | Les contrôles compacts, les segments et les actions utilisent ces tokens communs ; le hit target peut être supérieur à la hauteur visuelle. |

La police et les couleurs visibles dans Lovable doivent donc être comparées à ces
tokens de l’application actuelle. Lovable n’introduit pas de valeur concurrente :
il sert à valider la composition et l’apparence, tandis que le code reste la source
exécutable.

## Référence Lovable vérifiée

La référence active est le projet `Compact Controls Test`, identifié par
`52184df3-fbae-4c28-898f-d379409b03bd`. Le connecteur Lovable expose actuellement le
commit `75074e4d9b984ae9a72ee0dcc1cf7f6b990b1912`, qui remplace la référence précédemment
documentée `852fd99aae56a16aeaa47163aca3b426d8784b1d`.

- Le dernier changement Lovable étend explicitement la cible tactile des contrôles compacts
  et des actions de Discovery Card, et autorise le titre de carte sur deux lignes.
- Les tokens de couleur et la pile de police visibles restent alignés avec les tokens
  canoniques de production.
- L'arbitrage Discovery Card est validé : le shell partagé de production est aligné
  avec la référence Lovable pour le padding, la taille de titre, le rayon et l'ombre.
- L'alignement est porté par le contrat partagé `.ui-discovery-card` et les variables
  locales de `.ui-surface` ; la liste Entreprises n'ajoute
  pas d'override visuel propre.
- Le titre Discovery est désormais un rôle typographique sémantique partagé ; les
  signaux, métadonnées, badges et textes secondaires restent visuellement subordonnés.
- La recherche et son compteur restent côte à côte au viewport mobile de référence.
- Les filtres visibles restent en pills jusqu'à six choix ; les taxonomies plus larges
  dynamiques utilisent `DisclosureSurface` lorsque l’écran les expose.
- Les synthèses KPI restent compactes : jusqu'à trois `StatCard` sur une ligne, puis
  2 × 2 pour quatre et 3 × 2 pour cinq ou six avant de basculer le surplus en détail.

### Clôture Lot 7C

Le Lot 7C est validé le 21 septembre 2026 sur le commit `7146c7ad34ac2ef36c24b27bd8456bedd4cc069b`.
Le workflow `Visual review` (run GitHub Actions `35609644581`) est vert sur son périmètre :
lint, audit CSS de gouvernance, typecheck, couverture Storybook, build Storybook et captures Chromium.

La revue mobile à 390 px confirme :
- SearchField et compteur côte à côte ;
- jusqu'à six filtres visibles sous forme de pills ;
- les taxonomies larges représentées par `DisclosureSurface`, dans la page Entreprises ;
- trois `StatCard` compactes sur une ligne ;
- la hiérarchie typographique des `DiscoveryCard`, avec titre sémantique 15 px et contenus secondaires inférieurs ;
- les cas longs `Advanced Micro Devices — Long Reference Name` et `Lumentum Holdings — Optical Networking and Datacenter Infrastructure` sans collision avec badges, métadonnées ou actions.

Le compare Lovable → Storybook → production est donc fermé pour ce lot. La suite relève de la recette applicative complète du Lot 8 et de la review de merge.

La source Lovable expose notamment `src/components/CompactControl.tsx`,
`src/components/CompanyDiscoveryCard.tsx` et `src/routes/index.tsx`. Le projet
Lovable contient une page de référence visuelle et des composants de démonstration ;
il ne remplace pas les composants React de production du checkout.

## Mapping Lovable → React → Storybook

Les valeurs visuelles restent dans les tokens canoniques nommés ; cette table ne
recopie aucune valeur CSS. Une ligne correspond à un contrat visuel ; `DiscoveryCard`
porte le shell partagé de la liste Entreprises.

| Référence Lovable | Export React | Classe racine | Story / états vérifiés |
|---|---|---|---|
| Primary / secondary / glass surface | `Surface` | `.ui-surface` | `Foundations/Primitives — Surfaces`, `Design System/Overview` / trois rôles, nesting blanc |
| Progress indicator | `ProgressBar` | `.ui-progress-track` | `DataDisplay`, `Design System/Overview` / accent, positive, bounded value |
| Segmented filters | `SegmentedControl` | `.ui-control-group` | `Controls`, `Design System/Overview` / actif, contenu, clavier |
| Compact select / icon | `CompactControl` | `.ui-compact-control` | `Controls`, `Design System/Overview`, Portfolio / select, icon, disabled |
| Text action | `ActionButton` | `.ui-action-button` | `Controls`, `Design System/Overview` / normal, compact, focus |
| Back navigation | `BackButton` | `.ui-back-button` | `Controls`, Reader / normal, focus, accessible label |
| Badge / state | `Badge` | `.ui-badge` | `Badges / States`, `Design System/Overview` / neutral, accent, positive, warning, negative |
| Search toolbar | `SearchField` | `.ui-search-toolbar` | `Controls`, `Design System/Overview`, screen stories / empty, query, count |
| Section heading | `SectionHeader` | `.ui-section-header` | `Controls`, `Design System/Overview`, screen stories / h1, h2, metadata |
| Filter container | `FilterBar` | `.ui-filter-bar` | `Controls`, `Design System/Overview`, screen stories / labelled group |
| Tabs | `Tabs` | `.ui-tabs` | `Controls`, Company / active, arrow navigation, Home/End |
| KPI card | `StatCard` | `.ui-stat-card` | `Data display`, `Design System/Overview`, Company / normal, long value |
| Company directory card | `DiscoveryCard` | `.ui-discovery-card--company` | Entreprises, `Design System/Overview`, `Design System/ProductionVisualReview` / normal, long, no memo |
| Async state | `AsyncState` | `.ui-async-state` | `Badges / States`, screen state stories / empty, loading, error |
| Primary block | `PrimaryBlock` | `.ui-surface--primary` | Surfaces, `Design System/Overview`, screen stories / semantic wrapper |
| Secondary block | `SecondaryBlock` | `.ui-surface--secondary` | Surfaces, `Design System/Overview`, Reader / nested white content |
| Floating glass chrome | `GlassChrome` | `.ui-surface--glass` | Surfaces, `Design System/Overview` / chrome role |
| Disclosure details | `DisclosureSurface` | `.ui-disclosure-surface` | Content states, Reader, Company / closed, open |
| Metadata definition list | `MetadataGrid` | `.ui-metadata-grid` | Data display, `Design System/Overview`, Reader / labelled list |
| Data table | `DataTable` | `.ui-data-table-wrap` | Data display, `Design System/Overview`, Company / headers, rows, responsive labels |

## Accès et arbitrage

Le connecteur Lovable est utilisé pour synchroniser puis vérifier le projet, ses
sources et son commit de référence. Storybook reste la vérification reproductible
locale ; il ne remplace pas la validation visuelle Lovable.
