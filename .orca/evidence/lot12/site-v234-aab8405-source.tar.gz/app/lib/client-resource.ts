"use client";
import { useCallback, useEffect, useSyncExternalStore } from "react";
import { createResourceCache, emptyResource, type ResourceSnapshot } from "./resource-cache";
import { readBrowserNotionStatus } from "./notion-sync-client";

const cache = createResourceCache();
export type AppScope = "demo" | "personal";
type SessionState = { scope: AppScope; canAccessPersonal: boolean; ready: boolean };
let sessionState: SessionState = { scope: "demo", canAccessPersonal: false, ready: false };
const sessionListeners = new Set<() => void>();
const publishSession = (next: SessionState) => { sessionState = next; sessionListeners.forEach(listener => listener()); };
let sessionPromise: Promise<void> | undefined;
let sessionLoaded = false;
export function useAppSession() {
  const state = useSyncExternalStore(listener => { sessionListeners.add(listener); return () => sessionListeners.delete(listener); }, () => sessionState, () => ({ scope: "demo", canAccessPersonal: false, ready: false }));
  useEffect(() => { void loadAppSession(); }, []);
  return state;
}
export function loadAppSession() {
  if (sessionLoaded) return Promise.resolve();
  if (sessionPromise) return sessionPromise;
  sessionPromise = fetch("/api/session", { cache: "no-store" }).then(async response => {
    if (!response.ok) throw new Error("Session unavailable");
    const body = await response.json() as { scope?: unknown; canAccessPersonal?: unknown };
    publishSession({ scope: body.scope === "personal" ? "personal" : "demo", canAccessPersonal: body.canAccessPersonal === true, ready: true });
    sessionLoaded = true;
  }).catch(() => { publishSession({ scope: "demo", canAccessPersonal: false, ready: true }); sessionLoaded = true; }).finally(() => { sessionPromise = undefined; });
  return sessionPromise;
}
export async function switchAppScope(scope: AppScope) {
  if (scope === "personal" && !sessionState.canAccessPersonal) return;
  const response = await fetch("/api/session", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ scope }), cache: "no-store" });
  if (!response.ok) throw new Error("Changement d’espace refusé.");
  const body = await response.json() as { scope?: unknown; canAccessPersonal?: unknown };
  if ((body.scope === "personal" ? "personal" : "demo") !== scope) throw new Error("Espace demandé indisponible.");
  cache.clear();
  window.location.reload();
}
export function preloadResource(url: string) { void cache.read(url); }
export async function refreshResource(url: string) {
  await cache.read(url, true);
  const error = cache.snapshot(url).error;
  if (error) throw new Error(error);
}
export function resourceSnapshot<T>(url: string) { return cache.snapshot<T>(url); }
export function useResourceLifecycle() {
  useEffect(() => {
    let scheduled: number | undefined;
    let latestNotionSync: string | null | undefined;

    const checkNotionSync = async () => {
      try {
        const status = await readBrowserNotionStatus();
        const latest = (status.sources ?? [])
          .map(source => source.last_completed_at)
          .filter((value): value is string => Boolean(value))
          .sort()
          .at(-1) ?? null;
        if (latestNotionSync !== undefined && latest && (!latestNotionSync || latest > latestNotionSync)) {
          window.dispatchEvent(new Event("notion-sync-complete"));
        }
        latestNotionSync = latest;
      } catch {
        // Sync status is informational and must never block resource refreshes.
      }
    };

    const sync = () => {
      if (scheduled !== undefined) return;
      scheduled = window.setTimeout(() => {
        scheduled = undefined;
        cache.invalidate();
        cache.refreshActive();
      }, 250);
    };
    const resume = () => {
      if (document.visibilityState !== "visible") return;
      cache.refreshActive();
      void checkNotionSync();
    };
    window.addEventListener("notion-sync-complete", sync);
    window.addEventListener("online", resume);
    document.addEventListener("visibilitychange", resume);
    void checkNotionSync();
    return () => {
      window.removeEventListener("notion-sync-complete", sync);
      window.removeEventListener("online", resume);
      document.removeEventListener("visibilitychange", resume);
      if (scheduled !== undefined) window.clearTimeout(scheduled);
    };
  }, []);
}
export function useClientResource<T>(url: string, refreshQuery = false, enabled = true) {
  const snapshot = useSyncExternalStore<ResourceSnapshot<T>>(
    useCallback(listener => cache.subscribe(url, listener), [url]),
    useCallback(() => cache.snapshot<T>(url), [url]),
    () => emptyResource,
  );
  useEffect(() => { if (enabled) void cache.read(url); }, [url, enabled]);
  useEffect(() => { if (!snapshot.loading) window.dispatchEvent(new Event("app-view-ready")); }, [snapshot.loading]);
  useEffect(() => {
    if (enabled && url === "/api/portfolio/live" && (snapshot.data as { refreshPending?: boolean } | undefined)?.refreshPending) void cache.read(url, true, true);
  }, [enabled, url, snapshot.data]);
  const refresh = useCallback((forceProvider = false) => enabled ? cache.read(url, true, refreshQuery && forceProvider ? "force" : refreshQuery) : Promise.resolve(), [enabled, url, refreshQuery]);
  return { ...snapshot, refresh };
}
